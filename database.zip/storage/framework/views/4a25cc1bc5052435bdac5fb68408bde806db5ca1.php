<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
    <?php if(isset($title)): ?>
        <title><?php echo e($title); ?></title>
    <?php endif; ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="<?php echo e(asset('js/adminApp.js')); ?>" defer></script>
    <script src="https://yubinbango.github.io/yubinbango/yubinbango.js" charset="UTF-8"></script>

    <?php echo $__env->yieldContent('css'); ?>
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'baseUrl' => url('/'),
        ], JSON_UNESCAPED_UNICODE); ?>;
    </script>
</head>

<body class="c-app">
<div id="app">

    <div class="wrapper d-flex flex-column min-vh-100 bg-light">
        <?php echo $__env->make('include.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="body">
            <div>bạn phông đủ quyền truy cập vào trang quản trị</div>
        </div>
    </div>

</div>

<script src="<?php echo e(asset('js/coreui.bundle.min.js')); ?>"></script>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel9\resources\views/admin/vi.blade.php ENDPATH**/ ?>