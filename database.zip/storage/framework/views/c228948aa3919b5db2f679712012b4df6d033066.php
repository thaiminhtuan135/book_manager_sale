<header class="header header-sticky mb-2">
    <div class="container-fluid">
        <button class="header-toggler px-md-0 me-md-3" type="button"
            onclick="coreui.Sidebar.getInstance(document.querySelector('#sidebar')).toggle()">
            <i class="icon icon-lg fa fa-bars" aria-hidden="true"></i>
        </button>
        <ul class="header-nav ms-3">
            <li class="nav-item dropdown">
                <a class="nav-link py-0" data-coreui-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                    <div class="avatar avatar-md">
                        <img class="avatar-img" src="<?php echo e(url('/assets/img/avatars/6.jpeg')); ?>">
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-end pt-0">
                    <div class="dropdown-header bg-light py-2">
                        <div class="fw-semibold">Account</div>
                    </div>





                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                        <i class="icon me-2 fa fa-sign-out" aria-hidden="true"></i>
                        Đăng xuất
                    </a>
                </div>
            </li>
        </ul>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb border-0 m-0">

                <?php if(isset($breadcrumbs)): ?>
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key != count($breadcrumbs) - 1): ?>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['name']); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item active"><?php echo e($breadcrumb); ?></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ol>
        </nav>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\laravel9\resources\views/include/admin/header.blade.php ENDPATH**/ ?>