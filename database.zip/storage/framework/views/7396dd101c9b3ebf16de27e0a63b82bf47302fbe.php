<?php
use App\Components\SearchQueryComponent;
?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="fade-in">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <label>Danh sách công ty</label>
                            <div class="box-action">
                                <a href="<?php echo e(route('company.create')); ?>" class="btn btn-primary btn-action">
                                    <i class="fa fa-plus"></i>Thêm công ty
                                </a>
                            </div>
                        </div>
                        <div class="card-body">















                            <?php if(!$companyList->isEmpty()): ?>
                                <div class="row">
                                    <div class="col-md-5 col-sm-5 col-xs-12 group-select-page d-flex">
                                        <limit-page-option :limit-page-option="<?php echo e(json_encode([20, 50, 100])); ?>"
                                                           :new-size-limit="<?php echo e($newSizeLimit); ?>"></limit-page-option>
                                    </div>
                                    <div class="col-md-7 col-sm-7 col-xs-12 group-paginate">
                                        <?php echo e($companyList->appends(SearchQueryComponent::alterQuery($request))->links('vendor.pagination.bootstrap-4')); ?>

                                    </div>
                                </div>
                                <table class="table table-responsive-sm table-striped">
                                    <thead class="table-dark">
                                    <tr>
                                        <th>Code</th>
                                        <th>Name</th>
                                        <th>Telephone</th>
                                        <th>Address</th>
                                        <th class="w-100">
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $companyList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($company->code); ?></td>
                                            <td><?php echo e($company->name); ?></td>
                                            <td><?php echo e($company->telephone); ?></td>
                                            <td><?php echo e($company->address); ?></td>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-primary dropdown-toggle" id="action"
                                                            type="button" data-coreui-toggle="dropdown"
                                                            aria-expanded="false">Tùy chọn
                                                    </button>
                                                    <ul class="dropdown-menu" aria-labelledby="action">
                                                        <li>
                                                            <a class="dropdown-item"
                                                               href="<?php echo e(route('company.edit', $company->id)); ?>"
                                                               class="dropdown-item">
                                                                <i class="fa fa-eye"></i>Sửa
                                                            </a>
                                                        </li>
                                                        <li class="dropdown-divider"></li>
                                                        <li>
                                                            <btn-delete-confirm
                                                                :message-confirm="<?php echo e(json_encode('Bạn có chắc chắn muốn xóa？')); ?>"
                                                                :delete-action="<?php echo e(json_encode(route('company.destroy', $company->id))); ?>">
                                                            </btn-delete-confirm>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="group-paginate">
                                    <?php echo e($companyList->appends(SearchQueryComponent::alterQuery($request))->links('vendor.pagination.bootstrap-4')); ?>

                                </div>
                            <?php else: ?>
                                <data-empty></data-empty>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel9\resources\views/admin/company/index.blade.php ENDPATH**/ ?>