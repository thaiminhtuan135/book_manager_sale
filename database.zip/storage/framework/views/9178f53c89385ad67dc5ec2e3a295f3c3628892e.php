<?php $__env->startSection('content'); ?>
    <login :data="<?php echo e(json_encode([
    'request' => $request,
    'message' => $message ?? '',
])); ?>"></login>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel9\resources\views/login/index.blade.php ENDPATH**/ ?>