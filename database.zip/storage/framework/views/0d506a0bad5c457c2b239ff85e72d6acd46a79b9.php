<header class="header header-sticky mb-2">
    <div class="container-fluid">
        <button class="header-toggler px-md-0 me-md-3" type="button"
            onclick="coreui.Sidebar.getInstance(document.querySelector('#sidebar')).toggle()">
            <i class="icon icon-lg fa fa-bars" aria-hidden="true"></i>
        </button>























    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb border-0 m-0">

                <?php if(isset($breadcrumbs)): ?>
                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key != count($breadcrumbs) - 1): ?>
                            <li class="breadcrumb-item">
                                <a href="<?php echo e($breadcrumb['url']); ?>"><?php echo e($breadcrumb['name']); ?></a>
                            </li>
                        <?php else: ?>
                            <li class="breadcrumb-item active"><?php echo e($breadcrumb); ?></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ol>
        </nav>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\laravel9\resources\views/include/Admin/header.blade.php ENDPATH**/ ?>