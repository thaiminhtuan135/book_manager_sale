<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
        <?php if(isset($title)): ?>
            <title><?php echo e($title); ?></title>
        <?php endif; ?>
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <script src="<?php echo e(asset('js/adminApp.js')); ?>" defer></script>

        <?php echo $__env->yieldContent('css'); ?>
        <script>
            window.Laravel = <?php echo json_encode([
                'csrfToken' => csrf_token(),
                'baseUrl' => url('/'),
            ], JSON_UNESCAPED_UNICODE); ?>;
        </script>
    </head>

    <body class="c-app">
        <div id="app">
            <div class="c-wrapper">
                <div class="c-body">
                    <main class="c-main">
                        <?php echo $__env->yieldContent('content'); ?>
                    </main>
                </div>
            </div>
            <?php if(session()->get('Message.flash')): ?>
                <popup-alert :data="<?php echo e(json_encode(session()->get('Message.flash')[0])); ?>"></popup-alert>
            <?php endif; ?>
            <?php
                session()->forget('Message.flash');
            ?>
        </div>
        <div class="loading-div hidden">
            <div class="loader-img"></div>
        </div>
        <?php echo $__env->yieldContent('javascript'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel9\resources\views/layouts/guest.blade.php ENDPATH**/ ?>