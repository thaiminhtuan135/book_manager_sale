<?php $__env->startSection('content'); ?>
    <company-create
        :data="<?php echo e(json_encode([
            'urlStore' => route('company.store'),
            'title' => $title,
            'urlBack' => route('company.index'),
        ])); ?>">
    </company-create>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel9\resources\views/admin/company/create.blade.php ENDPATH**/ ?>