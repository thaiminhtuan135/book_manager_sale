<?php $__env->startSection('content'); ?>
    <test></test>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel9\resources\views/app.blade.php ENDPATH**/ ?>