@extends('layouts.admin')

@section('content')
    <company-create
        :data="{{ json_encode([
            'urlStore' => route('company.store'),
            'title' => $title,
            'urlBack' => route('company.index'),
        ]) }}">
    </company-create>
@endsection
