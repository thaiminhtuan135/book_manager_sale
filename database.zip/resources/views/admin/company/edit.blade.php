@extends('layouts.admin')
@section('content')
    <company-edit
        :data="{{json_encode([
            'urlUpdate' =>route('company.update',$company->id),
            'company' => $company,
            'title' => $title,
            'urlBack' => route('company.index'),
    ]) }}">
    </company-edit>
@endsection
