@extends('layouts.Admin')

@section('content')
    <test></test>
@endsection
