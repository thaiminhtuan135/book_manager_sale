<template>
  <div class="data-empty-message text-center alert alert-danger">
    該当データがありません
  </div>
</template>
