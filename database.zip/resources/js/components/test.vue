<template>
    <div class="container">
       tuan dep trai
    </div>
</template>

<script>


export default {
    setup() {

    },
    components: {

    },
    computed: {},
    props: [],
    data: function () {
        return {
            csrfToken: Laravel.csrfToken,
            flagShowLoader: false,
            model: {
                status: false,
            },
        };
    },
    created() {

    },
    methods: {

    },
};
</script>

