<?php

namespace App\Enums;

class UserRole
{
    const SYSTEM_ADMIN = 1;
    const ADMIN = 2;
    const USER = 3;
}
